package com.example.atenea;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText num_1;
    private EditText num_2;
    private TextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num_1=findViewById(R.id.num_1);
        num_2=findViewById(R.id.num_2);
        resultado=findViewById(R.id.resultado);
    }
    public void sumar(View view){
        String n1 = num_1.getText().toString();
        String n2 = num_2.getText().toString();
        int valor_1= Integer.parseInt(n1);
        int valor_2= Integer.parseInt(n2);
        int suma = valor_1+valor_2;
        String res = String.valueOf(suma);
        resultado.setText(res);
    }

}