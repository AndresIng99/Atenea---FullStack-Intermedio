package com.example.application;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText num1, num2;
    private TextView suma, resta, multiplicacion, division;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);
        suma = findViewById(R.id.suma);
        resta = findViewById(R.id.resta);
        multiplicacion = findViewById(R.id.multiplicacion);
        division = findViewById(R.id.division);

    }
    //ESTO ES UN METODO
    public void operacion(View view){
        String v1=num1.getText().toString();
        String v2=num2.getText().toString();
        double numero1=Double.parseDouble(v1);
        double numero2=Double.parseDouble(v2);


        double sum=numero1+numero2;
        double rest=numero1-numero2;
        double multi=numero1*numero2;
        double divi=numero1/numero2;

        String result_sum=String.valueOf(sum);
        String result_rest=String.valueOf(rest);
        String result_multi=String.valueOf(multi);
        String result_divi=String.valueOf(divi);

        suma.setText(result_sum);
        resta.setText(result_rest);
        multiplicacion.setText(result_multi);
        division.setText(result_divi);


    }
}