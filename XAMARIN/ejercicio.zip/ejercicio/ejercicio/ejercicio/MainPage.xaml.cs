﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace ejercicio
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
        public void fun_sumar(object sender, EventArgs e)
        {
            int numero1 = Convert.ToInt32(n1.Text);
            int numero2 = Convert.ToInt32(n2.Text);
            int sumar = numero1*numero2;

            DisplayAlert("Mensaje", sumar.ToString(),"Salir");
        }
    }
}
